package com.example.stackoverflow

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item.view.*

class recycler (private val UserName: ArrayList<String>): RecyclerView.Adapter<recycler.ItemHolder>() {
    class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        return ItemHolder(LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false))
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {

        val username=UserName[position]
        holder.itemView.apply {
            textView.text =username

        }
    }

    override fun getItemCount()= UserName.size

}