package com.example.stackoverflow

import android.os.AsyncTask
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    lateinit var rv: RecyclerView
    var askedQuestion = mutableListOf<question>()
    var questionrv = ArrayList<String>()
    var theText=""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rv = findViewById(R.id.recyclerView)

        rv.adapter = recycler(questionrv)
        rv.layoutManager = LinearLayoutManager(this)

        FetchTopSongs().execute()
    }

    private inner class FetchTopSongs : AsyncTask<Void, Void, MutableList<question>>() {
        val parser = XMLParser()
        override fun doInBackground(vararg params: Void?): MutableList<question> {
            val url = URL("https://stackoverflow.com/feeds")
            val urlConnection = url.openConnection() as HttpURLConnection
            askedQuestion =
                urlConnection.getInputStream()?.let {
                    parser.parse(it)
                }
                        as MutableList<question>
            return askedQuestion
        }

        override fun onPostExecute(result: MutableList<question>?) {
            super.onPostExecute(result)
          // val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, askedQuestion)
          //  rv.adapter = adapter
            for (i in askedQuestion){
                theText="#${i.title}"
                questionrv.add(theText)
            }
            rv.adapter?.notifyDataSetChanged()

        }

    }

}